var img1 = document.getElementById("character-1") ; 
var img2 = document.getElementById("character-2") ;
var img3 = document.getElementById("character-3") ;

var div1= document.getElementById("char-1");
var div2= document.getElementById("char-2");
var div3= document.getElementById("char-3");

var urlfetch = "/get3randomcharacters" ;

fetch(urlfetch).then(function(response){

    response.json().then(function(data){
        img1.setAttribute("src", `/images/${data[0].picture}`);
        img2.setAttribute("src", `/images/${data[1].picture}`);
        img3.setAttribute("src", `/images/${data[2].picture}`);

      
    })
})

function postPoll(idwin, idloose) {
    var body = {win:idwin, loose:idloose};
    var urlpoll = "/poll";
    fetch(urlpoll, {    method:'POST', 
                      body: JSON.stringify(body)  ,
                      headers:{'Content-Type': 'application/json'}, 
                      mode:"cors", 
                      cache:'default'}).then(
        function(response){ 
            window.location.reload();
        })
}